<?php

namespace sisVentas\Http\Controllers;

use Illuminate\Http\Request;

use sisVentas\Http\Requests;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use sisVentas\Http\Requests\IngresoFormRequest;
use sisVentas\Ingreso;
use sisVentas\DetalleIngreso;
use DB;

use Carbon\Carbon;
use Response;
use Illuminate\Support\Colletion;

class IngresoController extends Controller
{
     public function __construct()
    {

    }

    public function index(Request $request)
    {

    	if($request){
    		$query=trim($request->get('searchText'));
    		$ingreso=DB::table('ingreso as i')
    		->join('persona as p','i.idproveedor','=','p.idpersona')
    		->join('detalle_ingreso as di','i.idingreso','=','di.iddetalle_ingreso')
    		->select('i.idingreso','i.fecha_hora','p.nombre','i.tipo_comprobante')

    		->where('nombre','LIKE','%'.$query.'%')
    		->where('tipo_persona','=','Proveedor')
    		->orwhere('num_documento','LIKE','%'.$query.'%')
    		->where('tipo_persona','=','Proveedor')
    		->orderBy('idpersona','desc')
    		->paginate(7);
    		return view('compras.proveedor.index',["personas"=>$personas,"searchText"=>$query]);

    	}
    }
}
