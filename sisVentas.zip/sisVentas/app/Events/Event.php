<?php

namespace sisVentas\Events;

abstract class Event
{
    //
}
